# Most Pixels Ever

Most Pixels Ever is an open-source Java / C++ framework for spanning Processing sketches and openFrameWorks applications across multiple screens.

![Screenshot](http://farm3.static.flickr.com/2199/2124879919_6a8e447903_m.jpg)  ![Screenshot](http://farm3.static.flickr.com/2201/2125653100_1954bd6189_m.jpg)  ![Screenshot](http://farm3.static.flickr.com/2190/2124878313_c302b6aac7_m.jpg)

# Getting Started:

Check out the tutorials on the wiki!

[https://github.com/shiffman/Most-Pixels-Ever/wiki](https://github.com/shiffman/Most-Pixels-Ever/wiki)

# Credits:

Project initiated by Daniel Shiffman with the support of [http://itp.nyu.edu](ITP).

Participating developers: Jeremy Rotsztain, Elie Zananiri, Chris Kairalla.